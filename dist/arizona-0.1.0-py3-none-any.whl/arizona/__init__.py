# -*- coding: utf-8 -*-
# Copyright (c) 2021 by Phuc Phan

import logging

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
